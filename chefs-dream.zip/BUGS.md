# Bugs

This is a list of current bugs. None rn bc this datapack isn't even released lmao.