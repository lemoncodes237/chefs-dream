# Chef's Dream Changelog

v1.0.0
Coming Soon!

vBETA.2
Added beef stew, chicken noodle soup, pumpkin soup, cod stew, egg noodle soup, spaghetti with meatballs, banana bread, brownies, snickerdoodle, sweet berry cookie, honey cookie, orange bar, roasted mutton chops, grilled salmon, steak and potatoes, honey glazed ham, roast chicken, hot chocolate, fruit punch, coffee, melon juice, and glow berry delight

vBETA.1
Added recipe for chili cheese dog and chicken broth
Added texture for cooking station maker